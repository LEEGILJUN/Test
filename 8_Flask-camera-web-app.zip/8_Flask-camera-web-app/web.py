#!/usr/bin/env python
import os
import shutil
from flask import Flask, render_template, request, \
    Response, send_file, redirect, url_for
from camera import Camera
from send_email import Email
from tensorflow.keras.applications.mobilenet_v2 import preprocess_input
from tensorflow.keras.preprocessing.image import img_to_array
from tensorflow.keras.models import load_model
from imutils.video import VideoStream
import numpy as np
import argparse
import imutils
import time
import cv2
import os

print("[INFO] app initial")
app = Flask(__name__)
camera = None
#mail_server = None
#mail_conf = "static/mail_conf.json"

# 싱글톤 패턴을 구현하여 필요할 때 카메라의 단일 인스턴스를 느리게 로드
print("[INFO] Come on Camera!!")
def get_camera():
    global camera
    if not camera:
        camera = Camera()
    return camera
"""
# 메일서버 연결
def get_mail_server():
    global mail_server
    if not mail_server:
        mail_server = Email(mail_conf)
    return mail_server
"""

print("[INFO] Video Streaming home page")
@app.route('/') # 비디오 스트리밍 홈페이지 열음
def root():
    return redirect(url_for('index'))

#ㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡ
# 사진촬영 페이지 인덱스를 위한 루트
@app.route('/index/')
def index(): # 비디오 피드 카메라에서 프레임을 지속적으로 생성하는 반복자와 해당 mimetype
    #을 포함하는 Response 객체를 반환하여 multipart/x-mixed-replace 한 프레임을 다음
    #프레임으로 지속적으로 바꿀 수 있음
    return render_template('index.html')

# 카메라 프레임(이진이미지)를 지속적으로 가져오고 해당 이미지와 필요한 헤더를 포함하는 이진데이터를 반환하는 생성기 함수.
def gen(camera):
    while True:
        frame = camera.get_feed()
        yield (b'--frame\r\n'
               b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n')
#ㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡ
# 비디오 피드 템플릿 내 인덱스에서 이미지링크로 사용되는 경
@app.route('/video_feed/')
def video_feed():
    camera = get_camera()
    return Response(gen(camera),
        mimetype='multipart/x-mixed-replace; boundary=frame')
#ㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡ
# 캡처링 픽쳐를 위한 루트

@app.route('/capture/')
def capture():
    camera = get_camera()
    stamp = camera.capture()
    return redirect(url_for('show_capture', timestamp=stamp))

def stamp_file(timestamp):
    return 'captures/' + timestamp +".jpg"
#ㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡ
# 캡처된 사진 디스플레잉 하기 위한 루트

@app.route('/capture/image/<timestamp>', methods=['POST', 'GET'])
def show_capture(timestamp):
    path = stamp_file(timestamp)
    # 이메일 연결하는 루트
    email_msg = None
    if request.method == 'POST':
        if request.form.get('email'):
            email = get_mail_server()
            email_msg = email.send_email('static/{}'.format(path), 
                request.form['email'])
        else:
            email_msg = "Email field empty!"

    return render_template('capture.html',
        stamp=timestamp, path=path, email_msg=email_msg)

# 페이지열
if __name__ == '__main__':
#    model = joblib.load('./model/model.pkl')
    app.run(host='0.0.0.0', port=8080, debug=True)
# camera-app

Simple Flask-based web application for taking and storing pictures.

To run with Docker, run `docker-compose up`.

Picture taking app can be found on `127.0.0.1:8080` and storage (based on [Droppy](https://github.com/silverwind/droppy)) on `127.0.0.1:8080`.

You can find more info both on how this was built and how it is used in the tutorial I wrote over on dev.to: [dockerizing a Flask-based web camera application](https://dev.to/carlosemv/dockerizing-a-flask-based-web-camera-application-469m)

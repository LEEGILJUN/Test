# 터미널에서 경로들어가서 아래 문장 복붙하면 됩니다.
# python3 train_mask_detector.py --dataset dataset

# 박상무님 지시사항...OpenCV 라이브러리를 모바일넷으로 바꿔라
# 모바일넷은....학습된거 가져다 쓰는걸로..깩
# 입력 데이터 세트를 수락하고 MobileNetV2를 미세조정해서 mask_detector.model 을 트레이닝합니다
# plot 포함
# 필요한 패키지 가져옴
from tensorflow.keras.preprocessing.image import ImageDataGenerator
from tensorflow.keras.applications import MobileNetV2
from tensorflow.keras.layers import AveragePooling2D
from tensorflow.keras.layers import Dropout
from tensorflow.keras.layers import Flatten
from tensorflow.keras.layers import Dense
from tensorflow.keras.layers import Input
from tensorflow.keras.models import Model
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.applications.mobilenet_v2 import preprocess_input
from tensorflow.keras.preprocessing.image import img_to_array
from tensorflow.keras.preprocessing.image import load_img
from tensorflow.keras.utils import to_categorical
from sklearn.preprocessing import LabelBinarizer
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report
from imutils import paths
from keras.utils import plot_model
import matplotlib.pyplot as plt
import numpy as np
import argparse
import os

# argument 파서를 구성하고 arguments 를 파싱 
ap = argparse.ArgumentParser()
ap.add_argument("-d", "--dataset", required=True,
	help="path to input dataset")
ap.add_argument("-p", "--plot", type=str, default="plot.png",
	help="path to output loss/accuracy plot")
ap.add_argument("-m", "--model", type=str,
	default="mask_detector.model",
	help="path to output face mask detector model")
args = vars(ap.parse_args())

# 초기화 초기 러닝 레이트, 학습할 에포크 수, 배치크기
INIT_LR = 1e-4
EPOCHS = 20
BS = 64 # 32번 학습하고 검증하고 반복20반, 작을수록 가중치 갱신 많아질텐데...

# dataset 디렉토리에서 이미지 목록을 잡고 초기화
# 데이터 목록 및 클래스 이미지 
print("[INFO] loading images...")
imagePaths = list(paths.list_images(args["dataset"])) # 이미지가져오기
data = []
labels = []
print(imagePaths)
#test
print(data)
print(labels)

# 이미지 경로를 반복 
for imagePath in imagePaths: # imagePath변수에 위에 있던 imagePaths의 이미지들을 넣어가며 반복
        # 파일 이름에서 클래스 레이블을 추출합니다.
	label = imagePath.split(os.path.sep)[-2] # 뒤부터 -2 os모듈 import했고..os별로 경로 분리

        # 입력 이미지를 부르고 224 224 처리 
	image = load_img(imagePath, target_size=(224, 224))
	image = img_to_array(image)
	image = preprocess_input(image)

	# 데이터 및 라벨 목록을 각각 업데이트
	data.append(image)
	labels.append(label)

# 데이터와 레이블을 numpy 배열로 변환 
data = np.array(data, dtype="float32")
labels = np.array(labels)

# 라벨에 원핫 인코딩을 수행 
lb = LabelBinarizer()
labels = lb.fit_transform(labels)
labels = to_categorical(labels)

# 80%를 사용하여 데이터를 교육 및 테스트로 분할
# 훈련용 데이터 및 시험용은 나머지 20%
(trainX, testX, trainY, testY) = train_test_split(data, labels,
	test_size=0.20, stratify=labels, random_state=42)

# 데이터 확대를 위한 훈련 밎 구성
# 훈련하는 동안 노말라이즈드(일반화)를 개선하기 위해 이미지에 즉석으로 돌연변이를 적용한다(augment)
# 이를 임의 확대, 줌, 전단, 이동 및 반전 등의 매개변수를 설정한다, 데이터 확대 기법을 사용한 것
aug = ImageDataGenerator(
	rotation_range=20,
	zoom_range=0.15,
	width_shift_range=0.2,
	height_shift_range=0.2,
	shear_range=0.15,
	horizontal_flip=True,
	fill_mode="nearest")

# OpenCV-DNN에서 -> Mobilenet2으로 상무님 권장사항으로 안면검출모델로 선정
# 헤드 FC 레이어 세트가 보장되도록 mobilenet2 네트워크를 로드
# 미세조정을 ㄲㄲ
# 사전훈련된 이미지넷 가중치로 모바일넷을 로드하고 네트워크 헤드를 빼버림

#모바일넷이 케라스에서 제공한다는 정보 입수 차후 수정할지 고민필요
# https://keras.io/api/applications/
baseModel = MobileNetV2(weights="imagenet", include_top = False, input_tensor=Input(shape=(224, 224, 3))) # 기본 싸이즈
# weight 로딩할 가중치, 처음부터 훈련시키는데 관심있으면 None을 통해 사전에 훈련된 가중치 사용안해도됨
# include_top 출력 레이어를 포함할 것인지 여부를 개별 문제에 적합하게 되어 있다면 불필요
# input_tensor 서로다른 크기의 새로운 데이터에 모델을 맞추기위해 새로운 입력 레이어

# 위에 배치될 모델의 새로운 FC 헤드를 구성해주고
# 그 아래는 기본모델 가져다씀
headModel = baseModel.output
headModel = AveragePooling2D(pool_size=(7, 7))(headModel)
headModel = Flatten(name="flatten")(headModel)
headModel = Dense(128, activation="relu")(headModel)
headModel = Dropout(0.5)(headModel)
headModel = Dense(2, activation="softmax")(headModel)

# 헤드 fc 모델을 기본 모델 위에 놓습니다. 훈련할 실제모델입니다. 
model = Model(inputs=baseModel.input, outputs=headModel)

# 기본 모델의 모든 레이어를 반복하고 동결해서 
# 첫번째 train에서는 업데이트 안됨.
# 네트워크의 기본 계층을 고정함, 이러한 기본 계층의 가중치는 역전파 과정동안 업데이트 안되지만
# 헤드 계층 가중치는 조정될걸? 해보고 안되면 빼는걸로 ㅇㅇ
for layer in baseModel.layers:
	layer.trainable = False

# 기존에 유명한?? 알려진 모델에서 시나리오나 상황에 맞게 미세조정을 위해 데이터와 아키텍처를 구성해야

# 모델 컴파일함
# 아담 옵티마이저 쓰고 학습 속도가 중요한데...
# 신경망을 학습 할떄 가장 중요한 하이퍼 파라미터..
print("[INFO] compiling model...")
# lr : 0보다 크거나 같은 float 값 학습률
opt = Adam(lr=INIT_LR, decay=INIT_LR / EPOCHS) #옵티마이저 decay(learning rate decay) 학습률 감소 기법
# 0보다 크거나 같은 float값 업데이트마다 적용되는 학습률의 감소율
model.compile(loss="binary_crossentropy", optimizer=opt,
	metrics=["accuracy"]) # 클래스 카테고리 2개니까 바이너리 크로센트리 사용하자
# 교차 엔트로피 2개이상의 클래스가 있으면 범주형 교차 엔트로피를 사용해야함..


# 네트워크 헤드쪽 학습
# 데이터 보강객체 어그멘테이션(aug) 사용해서 변형 이미지 데이터를 일괄적으로 추가해줌...
# 차후 마스크 이미지 데이터 셋트 만들면 어그멘테이션 빼도 될듯한데???
print("[INFO] training head...")
H = model.fit(
	aug.flow(trainX, trainY, batch_size=BS),
	steps_per_epoch=len(trainX) // BS,
	validation_data=(testX, testY),
	validation_steps=len(testX) // BS,
	epochs=EPOCHS)

# 테스트 세트 프레딕션 해주기
print("[INFO] evaluating network...")
predIdxs = model.predict(testX, batch_size=BS)

# 테스트 세트의 각 이미지에 대한 가장큰 예측 확률이 있는레이블
predIdxs = np.argmax(predIdxs, axis=1)
# 테스트 세트를 예측하여 가장 높은 확률의 클래스 레이블 인덱스를 가져와서 프린트 검사를 위해,,,

# 잘 분류된 분류 레포트 프린트
print(classification_report(testY.argmax(axis=1), predIdxs,
	target_names=lb.classes_))

# 모델 디스크에서 안면 마스크 분류를 직렬화함..
# 머신러닝 모델을 저장하고 복원하는 몇가지 방법, pickle이나 dill사
print("[INFO] saving mask detector model...")
model.save(args["model"], save_format="h5") # 저장포멧은 가장 많이 쓰는 h5

# pickle 모듈은 파이썬 객체 구조의 직렬화와 역 직렬화를 위한 바이너리 프로토콜을 구현
# 파이썬 체 계층 구조가 바이트 스트림으로 변환되는 절차 이며 역 피클링은 반대연산이다
# 바이트 스트림을 객체 계층 구조로 복

# 정확도랑 손실곡선 프린트
N = EPOCHS
plt.style.use("ggplot")
plt.figure()
plt.plot(np.arange(0, N), H.history["loss"], label="train_loss")
plt.plot(np.arange(0, N), H.history["val_loss"], label="val_loss")
plt.plot(np.arange(0, N), H.history["accuracy"], label="train_acc")
plt.plot(np.arange(0, N), H.history["val_accuracy"], label="val_acc")
plt.title("Training Loss and Accuracy")
plt.xlabel("Epoch #")
plt.ylabel("Loss/Accuracy")
plt.legend(loc="lower left")
plt.savefig(args["plot"])

# 모델 아키텍처 그리기
plot_model(model, to_file='model.png')
plot_model(model, to_file='model_shapes.png', show_shapes=True)

# python3

import os
import shutil
from flask import Flask, render_template, request, \
    Response, send_file, redirect, url_for
from camera import Camera
from send_email import Email
from tensorflow.keras.applications.mobilenet_v2 import preprocess_input
from tensorflow.keras.preprocessing.image import img_to_array
from tensorflow.keras.models import load_model
from imutils.video import VideoStream
import numpy as np
import argparse
import imutils
import time
import cv2
import os


# 여기는 그냥 마스크 분류해주는 함수자넝..
print("[INFO] Mask classification")
# 편의 기능을 정의하면 나중에 프레임 처리 루프가 더 읽기 쉬우니까 ㅇㅇ
def detect_and_predict_mask(frame, faceNet, maskNet):
	# 프레임 크기 잡아주고 blob 만들어줌
	(h, w) = frame.shape[:2]
	blob = cv2.dnn.blobFromImage(frame, 2.0, (300, 300),
		(104.0, 177.0, 123.0))

	# 네트워크를 통해 blob통과시키고 얼굴 디텍션 얻음
	faceNet.setInput(blob) #faceNet가져와서 사용 https://github.com/davidsandberg/facenet
	detections = faceNet.forward() #얼굴 반복 탐지
	# frame은 스트림에서 나온 프레임
	# faceNet은 이미지에서 얼굴의 위치를 감지하는데 사용되는 모델
	# maskNet 얼굴 마스크 분류기 모델

	# 얼굴 목록과 해당 위치를 초기화함
	# 페이스 마스크 네트워크의 예측 목록
	faces = [] # RoI 얼굴
	locs = [] # face location
	preds = [] # 마스크 예측

	# 얼굴 탐지 반복돌림
	for i in range(0, detections.shape[2]):
		# 관련된 컨피던스(신뢰)를 추출함 확률같은거
		confidence = detections[0, 0, i, 2]

		# 신뢰도가 최소 신뢰도보다 큰지 확인하여 취약한 탐지를 필터링함
		if confidence > args["confidence"]:
			# 바운딩 박스의 (x, y) 좌표를 계산한다
			box = detections[0, 0, i, 3:7] * np.array([w, h, w, h])
			(startX, startY, endX, endY) = box.astype("int")

			# 루프내에서 경계상자 좌표가 이미지의 경계를 벗어나지 않도록 바운딩 감지 상자를 필터링하고
			# 경계상자룰 추출함
			(startX, startY) = (max(0, startX), max(0, startY))
			(endX, endY) = (min(w - 1, endX), min(h - 1, endY))

			# 얼굴 RoI 추출해서 BGR에서 RGB 채널로 변경하고 224x224 사이즈로 조정후 전처리
			face = frame[startY:endY, startX:endX]
			face = cv2.cvtColor(face, cv2.COLOR_BGR2RGB)
			face = cv2.resize(face, (224, 224))
			face = img_to_array(face)
			face = preprocess_input(face)
#			face = np.expand_dims(face, axis=0) # 마스크 한개만 인식하게 되는 코드라인
			# 제거하면 2개 인식함...
			# 전처리 후 RoI 및 바운딩박스를 해당 목록에 추

			# 얼굴이랑 바운딩 박스 추가함
			faces.append(face)
			locs.append((startX, startY, endX, endY))

	# 얼굴이 하나이상 감지된 경우만 예측..
	if len(faces) > 0:
		# 더 빠른 추론을 위해 올에 대해 배치 예측을함
		# 하나씩 예측하지 않고 동시에 하면 ...
	#	preds = maskNet.predict(faces)
		faces = np.array(faces, dtype="float32")
		# 얼굴 32비트 부동소수점을 넘파이 배열 변환
		preds = maskNet.predict(faces, batch_size=32)
		# 단일 이미지의 여러 얼굴이 마스크가 없는것으로 나오는데 이를 수정함
	 	# 추론하기 위해 수행하는 배치사이즈 전체의 페이스 프레임에 구성된 파이프라인이 오버헤드날까..
	 	# 각얼굴에 대해 개별적으로 예측하기 위한 다른 루프작성할 필요없음
		# 일괄 적으로 예측을 수행하는게 효율적일듯??

	# 얼굴 위치의 2-tuple하고 해당 위치를 반환
	return (locs, preds)


# 명령 행 인수
print("[INFO] Parser on")
ap = argparse.ArgumentParser() # 인자값을 받을 수 있는 인스턴스 생성
#입력받을 인자값 등록
ap.add_argument("-f", "--face", type=str, default="face_detector", help="path to face detector model directory")
ap.add_argument("-m", "--model", type=str, default="mask_detector.model", help="path to trained face mask detector model")
ap.add_argument("-c", "--confidence", type=float, default=0.5, help="minimum probability to filter weak detections")
#ap.add_argument("-p", "--port", action="store", default="8080")#안씀
# 입력받은 인자 값을 args에 저장
args = vars(ap.parse_args())
#port = int(args.port)
#app = detect_and_predict_mask()


# 파싱 구성
print("[INFO] loading face detector model...")
prototxtPath = os.path.sep.join([args["face"], "deploy.prototxt"])
weightsPath = os.path.sep.join([args["face"],
	"res10_300x300_ssd_iter_140000.caffemodel"])
faceNet = cv2.dnn.readNet(prototxtPath, weightsPath)

# 디스크에서 직렬화된 얼굴 탐지기 모델 로드
print("[INFO] loading face mask detector model...")
maskNet = load_model(args["model"])

# 비디오 스트림 초기화하고 카메라 센서 ㄱㄱ
print("[INFO] starting video stream...")
vs = VideoStream(src=0).start()
time.sleep(2.0)
#ㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡ


print("[INFO] app initial")
app = Flask(__name__)
camera = None
#mail_server = None
#mail_conf = "static/mail_conf.json"

# 싱글톤 패턴을 구현하여 필요할 때 카메라의 단일 인스턴스를 느리게 로드
print("[INFO] Come on Camera!!")
def get_camera():
    global camera
    if not camera:
        camera = Camera()
    return camera

print("[INFO] Video Streaming home page")
@app.route('/') # 비디오 스트리밍 홈페이지 열음
def root():
    return redirect(url_for('index'))
print("go to the index")
#ㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡ
# 사진촬영 페이지 인덱스를 위한 루트
print("[INFO] frame change")
@app.route('/index/')
def index(): # 비디오 피드 카메라에서 프레임을 지속적으로 생성하는 반복자와 해당 mimetype
    #을 포함하는 Response 객체를 반환하여 multipart/x-mixed-replace 한 프레임을 다음
    #프레임으로 지속적으로 바꿀 수 있음
    return render_template('index.html')

# 카메라 프레임(이진이미지)를 지속적으로 가져오고 해당 이미지와 필요한 헤더를 포함하는 이진데이터를 반환하는 생성기 함수.

print("[INFO] mask on the frame for display")
def gen(camera):
	while True:
		frame = camera.get_feed()
		yield (b'--frame\r\n'
			   b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n')
		(locs, preds) = detect_and_predict_mask(frame, faceNet, maskNet)

        # 탐지된 얼굴 위치와 해당하는 부분 반복
		for (box, pred) in zip(locs, preds):
			# 바운딩 박스와 예측
			(startX, startY, endX, endY) = box  # 얼굴 바운딩 박스
			(mask, withoutMask) = pred  # 쓴지 안쓴지 결정

			# 클래스 레이블이랑 색상 결정 해주기 BGR
			label = "Mask" if mask > withoutMask else "No Mask"
			color = (0, 255, 0) if label == "Mask" else (0, 0, 255)

			# 레이블에 확률 넣어주기
			label = "{}: {:.2f}%".format(label, max(mask, withoutMask) * 100)

			# 출력에 레이블과 바운딩 박스 표시
			cv2.putText(frame, label, (startX, startY - 10),
						cv2.FONT_HERSHEY_SIMPLEX, 0.45, color, 2)
			cv2.rectangle(frame, (startX, startY), (endX, endY), color, 2)


        # 출력 프레임 표시
      		#cv2.imshow("Frame", frame)

#ㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡ
# 비디오 피드 템플릿 내 인덱스에서 이미지링크로 사용되는 경
print("[INFO] video feed on")
@app.route('/video_feed/')
def video_feed():
    camera = get_camera()
    return Response(gen(camera),
        mimetype='multipart/x-mixed-replace; boundary=frame')
#ㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡ
# 캡처링 픽쳐를 위한 루트

# 페이지열자
print("[INFO] main start")
if __name__ == '__main__':
#    model = joblib.load('./model/model.pkl')
    app.run(host='0.0.0.0', port=8080, debug=True)
from tensorflow.keras.applications.mobilenet_v2 import preprocess_input
from tensorflow.keras.preprocessing.image import img_to_array
from tensorflow.keras.models import load_model
from imutils.video import VideoStream
import numpy as np
import argparse
import imutils
import time
import cv2
import os

def get_frame(self):
    image = self.stream.read()
    detector=cv2.CascadeClassifier('./')
    face = detector.detectMultiScale(image, 1.1, 7)
    for (x,y,h,w) in face:
        cv2.rectangle(image, (x, y), (x+w, y+h), (0, 255, 0),2)
    ret, jpg = cv2.imencode(',jpg', image)
    data = []
    data.append(jpg.tobyte())
    return data
